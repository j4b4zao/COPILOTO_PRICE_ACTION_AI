"""
brain/context_engine.py

Context Engine

RC11
"""

from ai.engine_base import EngineBase
from enums.trend import Trend


class ContextEngine(EngineBase):

    NAME = "ContextEngine"

    VERSION = "RC11"

    ENABLED = True

    PRIORITY = 60

    TREND_SCORE = 20
    BOS_SCORE = 15
    CHOCH_SCORE = 10

    LIQUIDITY_SCORE = 15

    HIGH_VOLUME_SCORE = 15
    MEDIUM_VOLUME_SCORE = 8

    ENGULFING_SCORE = 10
    HAMMER_SCORE = 8
    SHOOTING_STAR_SCORE = 8

    PULLBACK_SCORE = 10

    ORDER_BLOCK_SCORE = 20
    STRONG_ORDER_BLOCK = 10

    FVG_SCORE = 15
    STRONG_FVG_SCORE = 10

    # ==========================================================
    # EXECUTAR
    # ==========================================================

    def executar(self, context):

        result = context.context
        evidence = context.evidence

        result.clear()

        score = 0

        score += self._structure(context)
        score += self._liquidity(context)
        score += self._volume(context)
        score += self._price_action(context)
        score += self._order_block(context)
        score += self._fair_value_gap(context)

        result.score = min(score, 100)

        result.confluences = len(result.reasons)

        result.confidence = result.score / 100

        self._classify(context)

        return context

    # ==========================================================
    # STRUCTURE
    # ==========================================================

    def _structure(self, context):

        structure = context.structure
        result = context.context

        score = 0

        if structure.trend == Trend.UP:
            score += self.TREND_SCORE
            result.add_reason("Trend UP")

        elif structure.trend == Trend.DOWN:
            score += self.TREND_SCORE
            result.add_reason("Trend DOWN")

        if structure.bos_up or structure.bos_down:
            score += self.BOS_SCORE
            result.add_reason("BOS")

        if structure.choch:
            score += self.CHOCH_SCORE
            result.add_reason("CHoCH")

        return score

    # ==========================================================
    # LIQUIDITY
    # ==========================================================

    def _liquidity(self, context):

        liquidity = context.liquidity
        result = context.context

        score = 0

        if liquidity.sweep_down:
            score += self.LIQUIDITY_SCORE
            result.add_reason("Buy Side Liquidity")

        if liquidity.sweep_up:
            score += self.LIQUIDITY_SCORE
            result.add_reason("Sell Side Liquidity")

        return score

    # ==========================================================
    # VOLUME
    # ==========================================================

    def _volume(self, context):

        volume = context.volume
        result = context.context

        score = 0

        if volume.high:
            score += self.HIGH_VOLUME_SCORE
            result.add_reason("High Volume")

        elif volume.medium:
            score += self.MEDIUM_VOLUME_SCORE
            result.add_reason("Medium Volume")

        return score

    # ==========================================================
    # PRICE ACTION
    # ==========================================================

    def _price_action(self, context):

        price = context.price_action
        result = context.context

        score = 0

        if price.bullish_engulfing:
            score += self.ENGULFING_SCORE
            result.add_reason("Bullish Engulfing")

        if price.bearish_engulfing:
            score += self.ENGULFING_SCORE
            result.add_reason("Bearish Engulfing")

        if price.hammer:
            score += self.HAMMER_SCORE
            result.add_reason("Hammer")

        if price.shooting_star:
            score += self.SHOOTING_STAR_SCORE
            result.add_reason("Shooting Star")

        if price.pullback:
            score += self.PULLBACK_SCORE
            result.add_reason("Pullback")

        return score

    # ==========================================================
    # ORDER BLOCK
    # ==========================================================

    def _order_block(self, context):

        ob = context.order_block
        result = context.context

        score = 0

        if ob.bullish:
            score += self.ORDER_BLOCK_SCORE
            result.add_reason("Bullish Order Block")

        elif ob.bearish:
            score += self.ORDER_BLOCK_SCORE
            result.add_reason("Bearish Order Block")

        if ob.strength >= 0.80:
            score += self.STRONG_ORDER_BLOCK
            result.add_reason("Strong Order Block")

        return score

    # ==========================================================
    # FAIR VALUE GAP
    # ==========================================================

    def _fair_value_gap(self, context):

        fvg = context.fair_value_gap
        result = context.context

        score = 0

        if fvg.bullish:
            score += self.FVG_SCORE
            result.add_reason("Bullish FVG")

        elif fvg.bearish:
            score += self.FVG_SCORE
            result.add_reason("Bearish FVG")

        if fvg.strength >= 0.80:
            score += self.STRONG_FVG_SCORE
            result.add_reason("Strong FVG")

        return score

    # ==========================================================
    # CLASSIFICAÇÃO
    # ==========================================================

    def _classify(self, context):

        result = context.context
        evidence = context.evidence
        structure = context.structure

        if result.score >= 80:

            result.market_state = "FAVORABLE"

            result.bias = (
                "BUY"
                if structure.trend == Trend.UP
                else "SELL"
            )

            result.valid = True

            evidence.add("FAVORABLE_CONTEXT")

        elif result.score >= 60:

            result.market_state = "NEUTRAL"

            result.bias = "NONE"

            result.valid = True

            evidence.add("NEUTRAL_CONTEXT")

        else:

            result.market_state = "UNFAVORABLE"

            result.bias = "NONE"

            result.valid = False

            evidence.add("UNFAVORABLE_CONTEXT")