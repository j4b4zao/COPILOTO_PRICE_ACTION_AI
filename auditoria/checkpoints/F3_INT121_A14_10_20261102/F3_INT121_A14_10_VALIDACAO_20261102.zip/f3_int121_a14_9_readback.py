"""Private bounded retries for offline journal reads; no operational API use.

The budget bounds retries, not OS scheduling or a blocking filesystem call.
"""
import time
import f3_int121_a14_8_journal as journal


def read(path, expected, timeout=0.5, after_denial=None):
    if type(timeout) not in (int,float) or not 0 < timeout <= 5:
        raise ValueError('Private retry budget must be positive and at most five seconds')
    started=time.perf_counter_ns()
    deadline=started+int(timeout*1_000_000_000)
    attempts=[]
    raw=None
    error=None
    verification=None
    status=None
    while True:
        begin=time.perf_counter_ns()
        if attempts and begin >= deadline:
            status='JOURNAL_READ_DENIED'
            break
        try:
            raw=path.read_bytes()
        except OSError as caught:
            error=dict(type=type(caught).__name__,errno=caught.errno,
                       winerror=getattr(caught,'winerror',None),message=str(caught))
            attempts.append(dict(started_ns=begin,finished_ns=time.perf_counter_ns(),error=dict(error)))
            if isinstance(caught,FileNotFoundError):
                status='JOURNAL_MISSING'
                break
            if not isinstance(caught,PermissionError):
                status='JOURNAL_READ_ERROR'
                break
            # Private observer hook coordinates release of a genuine OS handle;
            # Path.read_bytes and its failures are never mocked.
            if after_denial is not None:
                after_denial(dict(error))
            remaining=(deadline-time.perf_counter_ns())/1_000_000_000
            if remaining>0:
                time.sleep(min(0.01,remaining))
        else:
            attempts.append(dict(started_ns=begin,finished_ns=time.perf_counter_ns(),error=None))
            verification=journal.compare(raw,expected)
            status=verification['reason']
            error=None
            break
    return dict(status=status,raw=raw,error=error,verification=verification,attempts=attempts,
                started_ns=started,deadline_ns=deadline,finished_ns=time.perf_counter_ns(),
                strict_deadline_guaranteed=False,production_api_changed=False)
