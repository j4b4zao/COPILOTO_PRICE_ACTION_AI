# Reproduzir a regressão A14.5-R2

Windows nativo, PowerShell 7 ou superior, Python com `cryptography` já instalado. Não há download ou instalação de dependências.

Na pasta que contém `executar_regressao_r2.ps1` e `auditar_regressao.py`:

```powershell
.\executar_regressao_r2.ps1 `
  -SourceZip 'C:\Users\jb\Downloads\F3_INT121_A14_5_R2_DIAGNOSTICO_CORRIDA_20261029.zip' `
  -PythonPath 'C:\COPILOTO_PRICE_ACTION_AI\ambiente\Scripts\python.exe' `
  -Destination 'C:\Users\jb\Documents\Codex\regressao_r2_nova_execucao'
```

O destino precisa ser novo. O executor verifica o hash conhecido do ZIP, os hashes do manifesto e a descoberta de 180 testes. Executa normal e otimizado sequencialmente e grava logs, códigos de saída e a auditoria JSON em `Destination\logs`. Os intermediários ficam em `Destination\work`. Nenhum arquivo do projeto principal é substituído.

As regressões desta sessão foram executadas diretamente com Python 3.12.14 e `cryptography` 50.0.2, disponíveis no runtime local. O ambiente Python 3.13.5 do projeto também respondeu à verificação de importação, mas não foi usado nas duas regressões consolidadas. Para reproduzir com o mesmo runtime, use:

```text
C:\Users\jb\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
```

O executor PowerShell passou na análise sintática; sua execução completa não foi repetida. O auditor foi conferido com contraprovas sintéticas e com as evidências reais desta sessão.

O aceite é local e limitado à suíte R2. F3 permanece OPEN, offline e simulation_only; operações reais bloqueadas. O executor não publica no GitHub nem modifica branches.
