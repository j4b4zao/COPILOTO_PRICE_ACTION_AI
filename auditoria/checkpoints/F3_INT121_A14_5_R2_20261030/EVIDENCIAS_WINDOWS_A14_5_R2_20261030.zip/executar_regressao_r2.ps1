#requires -Version 7.0
param(
    [Parameter(Mandatory=$true)][string]$SourceZip,
    [Parameter(Mandatory=$true)][string]$PythonPath,
    [Parameter(Mandatory=$true)][string]$Destination
)

# Nova pasta isolada. Nenhum download, instalacao, git ou operacao real.
$ErrorActionPreference = 'Stop'
$sourcePath = (Resolve-Path -LiteralPath $SourceZip).Path
$pythonExe = (Resolve-Path -LiteralPath $PythonPath).Path
$targetPath = [System.IO.Path]::GetFullPath($Destination)
$auditorPath = Join-Path $PSScriptRoot 'auditar_regressao.py'
if (-not (Test-Path -LiteralPath $auditorPath -PathType Leaf)) {
    throw 'auditar_regressao.py deve acompanhar este executor.'
}
if (Test-Path -LiteralPath $targetPath) {
    throw 'Destination deve ser uma pasta nova; nenhum resultado existente sera sobrescrito.'
}
$expectedHash = '9426adc9917158c87cbdf5c8ff5a5cfba9e6c4dfcbcd716cae4596a0deda377e'
if ((Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $expectedHash) {
    throw 'SHA-256 do ZIP difere da origem A14.5-R2 auditada.'
}
& $pythonExe -B -c 'import sys, cryptography; print(sys.version); print(cryptography.__version__)'
if ($LASTEXITCODE -ne 0) { throw 'Interpretador sem cryptography funcional.' }
New-Item -ItemType Directory -Path $targetPath | Out-Null
$srcPath = Join-Path $targetPath 'src'
$logsPath = Join-Path $targetPath 'logs'
New-Item -ItemType Directory -Path $logsPath | Out-Null
$prepare = @'
import hashlib, json, os, sys, unittest
from pathlib import Path
from zipfile import ZipFile
if os.name != 'nt':
    raise SystemExit('Windows nativo obrigatorio; nao aceitar skips de plataforma')
source, destination = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
with ZipFile(source) as archive:
    if archive.testzip() is not None:
        raise SystemExit('ZIP corrompido')
    for member in archive.infolist():
        candidate = (destination / member.filename).resolve()
        if not candidate.is_relative_to(destination):
            raise SystemExit('Caminho inseguro no ZIP')
    archive.extractall(destination)
manifest = json.loads((destination / 'audit/A14_5/MANIFESTO_R2_SHA256.json').read_bytes())
for name, expected in manifest['files_sha256'].items():
    path = (destination / name).resolve()
    if not path.is_relative_to(destination) or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit('Manifesto divergente: ' + name)
sys.path.insert(0, str(destination))
suite = unittest.defaultTestLoader.discover(str(destination), pattern='test_*.py')
if suite.countTestCases() != 180:
    raise SystemExit('Descoberta diferente de 180 testes')
print('ZIP, manifesto e descoberta de 180 testes conferidos')
'@
& $pythonExe -B -c $prepare $sourcePath $srcPath
if ($LASTEXITCODE -ne 0) { throw 'Preparacao reprovada; consulte a pasta isolada.' }

Push-Location -LiteralPath $srcPath
try {
    foreach ($mode in @('normal', 'otimizado')) {
        $logPath = Join-Path $logsPath "regressao_a14_5_r2_$mode.log"
        $exitPath = Join-Path $logsPath "regressao_a14_5_r2_$mode.exit.txt"
        $pythonArgs = @('-B')
        if ($mode -eq 'otimizado') { $pythonArgs += '-O' }
        $pythonArgs += @('-m', 'unittest', 'discover', '-s', '.', '-p', 'test_*.py', '-q')
        Write-Output "Executando $mode; log: $logPath"
        & $pythonExe @pythonArgs *> $logPath
        $testExit = $LASTEXITCODE
        Set-Content -LiteralPath $exitPath -Value $testExit -Encoding utf8
        Write-Output "Modo $mode terminado; exit=$testExit"
    }
} finally {
    Pop-Location
}
$normalLog = Join-Path $logsPath 'regressao_a14_5_r2_normal.log'
$optimizedLog = Join-Path $logsPath 'regressao_a14_5_r2_otimizado.log'
$auditResult = Join-Path $logsPath 'AUDITORIA.json'
$validate = @'
import importlib.util, json, sys
from pathlib import Path
module_path, normal, optimized, root, output = sys.argv[1:]
spec = importlib.util.spec_from_file_location('auditor', module_path)
auditor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(auditor)
result = dict(f3='OPEN', offline=True, simulation_only=True,
              real_operations_authorized=False,
              modes=[auditor.audit(normal, 0), auditor.audit(optimized, 1)],
              boundaries=auditor.audit_boundaries(Path(root) / 'work'))
result['accepted'] = all(m['accepted'] for m in result['modes']) and result['boundaries']['accepted']
Path(output).write_text(json.dumps(result, indent=2), encoding='utf-8')
print('Auditoria aceita:', result['accepted'])
raise SystemExit(0 if result['accepted'] else 1)
'@
& $pythonExe -B -c $validate $auditorPath $normalLog $optimizedLog $targetPath $auditResult
if ($LASTEXITCODE -ne 0) { throw "Regressao/auditoria nao aprovada. Evidencias: $logsPath" }
Write-Output "Regressao R2 aprovada nos dois modos. F3 OPEN; operacoes reais bloqueadas. $auditResult"
