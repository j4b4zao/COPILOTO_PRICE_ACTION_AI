# COPILOTO_PRICE_ACTION_AI — retomada 30/10/2026

Estado A14.5-R2: **REGRESSAO_NAO_APROVADA**.

F3 OPEN; offline; simulation_only; operações reais bloqueadas. Nenhum arquivo do projeto principal foi alterado.

## Evidências atuais

| Modo | Resultado auditado | Testes / duração |
|---|---|---|
| Normal | Aprovado | 180 / 900,334 s |
| Otimizado (-O) | Não aprovado | 180 / 966,618 s |

Falha de auditoria: Codigo de saida ausente ou diferente de zero

Falha de auditoria: Resumo final nao e OK sem skips

Falha de auditoria: Log contem falha ou traceback

Falha de auditoria de fronteira: Modo 1: esperados 12 registros distintos de fronteira

Auditoria de fronteiras: 23 registros; nao aprovada.

A suíte tem 180 identificadores distintos. Os 166 arquivos da pasta de testes correspondem ao ZIP; os 165 hashes do manifesto R2 conferem. O Python 3.13 base falhou por dependência ausente antes da execução da suíte. As regressões consolidadas usam o runtime local Python 3.12.14 com cryptography 50.0.2.

Os anexos históricos reais foram relidos: a regressão A14.5 anterior registrou 180 testes e uma falha de sobrevivência em 342,989 s; os específicos R2 de 29/10 registraram 2/2 em cada modo, 32,340 s e 32,416 s. O ZIP final documental A14.4 registra 178 testes por modo e preserva F3 OPEN. Esses registros históricos não substituem os resultados da execução atual.

A14.5-R2 avalia observação e limpeza repetidas. A ausência de sobreviventes em uma repetição é uma observação válida, sem provar contenção interna. Os controles estritos A14.4 permanecem exigidos.

## Preservação e GitHub

Repositório original: C:\COPILOTO_PRICE_ACTION_AI. Branch local brooks-stop-target-exact-audit-20260912; HEAD 3ca24e4f4d9cfe76df4422930dea1e5b26c7dfcb. As referências remotas locais indicam ahead 2 / behind 14, sem fetch nesta sessão. O Git apontou 5.010 caminhos com D; há diretórios ausentes ou inacessíveis ao usuário de sandbox, portanto isso não comprova que todos foram apagados. Não foi executado reset, limpeza, merge, commit ou push.

O conector encontrou j4b4zao/COPILOTO_PRICE_ACTION_AI, mas a consulta do commit 3ca24e4 respondeu 422 (commit não encontrado). O título do commit local menciona o checkpoint R2, porém a busca de caminhos na árvore do commit não encontrou A14_5_R2 nem F3_INT121. Não há confirmação de backup desse pacote no GitHub.

## Retomada

1. Revisar o checkpoint JSON e os logs completos incluídos.
2. Resolver a localização/versionamento do checkpoint e ZIP antes de sincronizar a branch divergente; preservar o estado existente.
3. Revisar a proposta A14.6 solicitada: barreira e handshake para uma contraprova de sobrevivência controlada. Os critérios são propostos nesta retomada; A14.6 não foi implementada nem aprovada como marco.
4. Manter os bloqueios operacionais; esta validação não certifica produção, custódia independente, durabilidade física ou todos os escalonamentos.
