# A14.6-R2 — fixture estrita com bridge retido

A14_6_R2_VALIDADA_LOCALMENTE

F3 OPEN; offline; simulation_only; operacoes reais bloqueadas.

O manifesto vigente esta em audit/A14_6_R2/. Manifestos herdados sao historicos. Os cenarios observacionais A14.5 usam a saida natural; apenas os controles estritos A14.4 worker-first/rapida sucessao usam retencao explicita. Nenhuma assercao estrita foi removida.

Em pasta nova isolada no Windows, executar os modos sequencialmente:

```powershell
python -B -m unittest discover -s . -p "test_*.py" -q
python -O -B -m unittest discover -s . -p "test_*.py" -q
```

Esperados 192 testes por modo; Python 3.13.5/cryptography 50.0.2 foram usados nesta validacao. A primeira revisao com uma falha foi preservada no ZIP em audit/A14_6_R2/origem/. Nenhuma instalacao operacional e autorizada.
